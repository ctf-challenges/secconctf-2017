/*
 * Simple inetd server.
 *
 * simple-inetd <address> <port> <uid> <gid> <dir> <command> [<arg0>...]
 *
 * Example:
 * simple-inetd any 10000 1001 1001 /home/user print-argv print-argv abc def
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* #define HANDOVER_ENVVAL */
#define CONNECT_STDERR_TO_SOCKET
#define NO_CHANGE_ROOTDIR
#define NO_CHANGE_USER
/* #define BUFFER_NEWLINE */
#define CONNECT_LIMIT 5
#define CONNECT_LIMIT_NETMASK 0xffffff00
#define RELAY_LIMIT
#define RELAY_LIMIT_DISCONNECT
#define LOGGING_CONNECT_FROM "/tmp/simple-inetd.log"

typedef struct {
  int uid;
  int gid;
  char *dir;
  char *command;
  int argc;
  char **argv;
  char **envp;
} param_t;

static volatile int finished = 0;

static void sigchld_handler(int val)
{
  int status;
  wait(&status);
  finished = 1;
}

static int create_socket(in_addr_t addr, int port)
{
  int s, ret, on = 1;
  struct sockaddr_in address;

  s = socket(AF_INET, SOCK_STREAM, 0);
  if (s < 0) {
    perror("socket()");
    exit(-1);
  }

  ret = setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
  if (ret < 0) {
    perror("setsockopt()");
    exit(-1);
  }

  memset(&address, 0, sizeof(address));
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = htonl(addr);
  address.sin_port = htons(port);

  ret = bind(s, (struct sockaddr *)&address, sizeof(address));
  if (ret < 0) {
    perror("bind()");
    exit(-1);
  }

  ret = listen(s, 5);
  if (ret < 0) {
    perror("listen()");
    exit(-1);
  }

  return s;
}

static int connect_server(in_addr_t addr, int port)
{
  int s, ret;
  struct sockaddr_in address;
  int i;

  s = socket(AF_INET, SOCK_STREAM, 0);
  if (s < 0) {
    perror("socket()");
    exit(-1);
  }

  for (i = 0; i < 10; i++) {
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(addr);
    address.sin_port = htons(port);

    ret = connect(s, (struct sockaddr *)&address, sizeof(address));
    if (ret >= 0)
      break;
    sleep(1);
  }
  if (ret < 0) {
    perror("connect()");
    exit(-1);
  }

  return s;
}

static int writestr(int s, char *buf)
{
  write(s, buf, strlen(buf));
  return 0;
}

#ifdef BUFFER_NEWLINE
static int search_newline(char *p, int size)
{
  int i;
  for (i = 0; i < size; i++) {
    if (p[i] == '\n')
      return i;
  }
  return -1;
}
#endif

static int buffer_move(char *dst, char *src, int size)
{
  for (; size > 0; size--) {
    *(dst++) = *(src++);
  }
  return 0;
}

#ifdef RELAY_LIMIT
static int get_size(char *file)
{
  FILE *fp;
  char buffer[32];

  fp = fopen(file, "r");
  if (!fp)
    return -1;

  fgets(buffer, sizeof(buffer), fp);
  fclose(fp);

  return atoi(buffer);
}
#endif

static int read_write(int from, int to, char *buffer, int bufsize, int *pp,
		      int *offset, int maxsize)
{
  int size;
  int p, s;

  size = read(from, &buffer[*pp], bufsize - *pp);
  if (size <= 0)
    return -1;

  *pp += size;
#ifdef BUFFER_NEWLINE
  p = search_newline(buffer, *pp);
  if ((p < 0) && (*pp == bufsize))
    p = bufsize - 1;
#else
  p = *pp - 1;
#endif
  if (p >= 0) {
    p++;
    s = p;
#ifdef RELAY_LIMIT
    if ((maxsize >= 0) && (*offset + s > maxsize))
      s = maxsize - *offset;
#ifdef RELAY_LIMIT_DISCONNECT
    if (s < 0)
      return -1;
#endif
#endif
    if (s > 0)
      write(to, buffer, s);
    buffer_move(buffer, &buffer[p], *pp - p);
    *pp -= p;
    *offset += p;
  }

  return 0;
}

static int relay(int fd0, int fd1)
{
  int n, r;
  char buf0[1024*16];
  char buf1[1024*16];
  int p0 = 0, p1 = 0;
  int off0 = 0, off1 = 0;
  int maxsize = -1;
  fd_set fds;

  n = fd0;
  if (n < fd1) n = fd1;

  while (!finished) {
    FD_ZERO(&fds);
    FD_SET(fd0, &fds);
    FD_SET(fd1, &fds);
    r = select(n + 1, &fds, NULL, NULL, NULL);
    if (r < 0)
      break;
    if (r > 0) {
      if (FD_ISSET(fd0, &fds)) {
#ifdef RELAY_LIMIT
	maxsize = get_size("/tmp/size.txt");
#endif
	if (read_write(fd0, fd1, buf0, sizeof(buf0), &p0, &off0, maxsize) < 0)
	  break;
      }
      if (FD_ISSET(fd1, &fds)) {
	if (read_write(fd1, fd0, buf1, sizeof(buf1), &p1, &off1, -1) < 0)
	  break;
      }
    }
  }

  return 0;
}

static int command_exec(param_t *p)
{
  if (strcmp(p->dir, "NOCHROOT")) {
    if (chdir(p->dir) < 0) {
      writestr(1, "fail chdir.\n");
      _exit(1);
    }

#ifndef NO_CHANGE_ROOTDIR
    if (chroot(".") < 0) {
      writestr(1, "fail chroot.\n");
      _exit(1);
    }

    if (chdir("/") < 0) {
      writestr(1, "fail chdir.\n");
      _exit(1);
    }
#endif
  }

#ifndef NO_CHANGE_USER
  if (p->gid) {
    if (setgid(p->gid) < 0) {
      writestr(1, "fail setgid.\n");
      _exit(1);
    }
  }

  if (p->uid) {
    if (setuid(p->uid) < 0) {
      writestr(1, "fail setuid.\n");
      _exit(1);
    }
  }
#endif

  if (execve(p->command, p->argv, p->envp) < 0) {
    writestr(1, "fail exec.\n");
    _exit(1);
  }

  return 0;
}

static int server_proc(int s, param_t *p)
{
  int pid;
  int s2, port, i;
  struct timeval t;
  char *sp;

  pid = fork();
  if (pid < 0) {
    writestr(s, "fail fork.\n");
    exit(1);
  }
  if (pid) { /* parent */
    return 0;
  }

  /* child process */

  finished = 0;

  gettimeofday(&t, NULL);
  port = (((unsigned int)(t.tv_sec + t.tv_usec + rand())) % 10000) + 40000;

  for (i = 0; i < p->argc; i++) {
    sp = strstr(p->argv[i], "RANDPORT");
    if (sp) {
      sprintf(sp, "%d", port);
    }
  }

  pid = fork();
  if (pid < 0) {
    writestr(s, "fail fork.\n");
    exit(1);
  }
  if (pid) { /* parent */
    sleep(1); /* wait for child process */
    s2 = connect_server(INADDR_LOOPBACK, port);
    relay(s, s2);
    shutdown(s, SHUT_RDWR);
    shutdown(s2, SHUT_RDWR);
    sleep(1); /* wait for shutdown */
    close(s);
    close(s2);
    kill(pid, SIGINT);
    _exit(0);
  }

  command_exec(p);
  _exit(0);
}

#ifdef CONNECT_LIMIT
struct address_list {
  struct address_list *next;
  struct sockaddr_in address;
  time_t last_connect;
};

static int check_connect_limit(struct sockaddr_in *address)
{
  static struct address_list *list = NULL;
  static struct address_list *p, **pp;
  time_t now;

  now = time(NULL);

  for (pp = &list; *pp;) {
    if (now - (*pp)->last_connect >= CONNECT_LIMIT) {
      p = *pp;
      *pp = (*pp)->next;
      free(p);
    } else {
      pp = &(*pp)->next;
    }
  }

  for (p = list; p; p = p->next) {
    if ((ntohl(p->address.sin_addr.s_addr) & CONNECT_LIMIT_NETMASK) ==
	(ntohl(address->sin_addr.s_addr) & CONNECT_LIMIT_NETMASK)) {
#if 0
      if (now - p->last_connect >= CONNECT_LIMIT) {
	p->last_connect = now;
	return 1;
      }
#endif
      return -1;
    }
  }

  p = malloc(sizeof(*p));
  if (p == NULL)
    return -1;
  memset(p, 0, sizeof(*p));
  memcpy(&p->address, address, sizeof(p->address));
  p->last_connect = now;

  p->next = list;
  list = p;

  return 0;
}
#endif

#ifdef LOGGING_CONNECT_FROM
static int logging_connect(struct sockaddr_in *address, int port)
{
  int fd;
  char str[64];

  fd = open(LOGGING_CONNECT_FROM, O_RDWR|O_CREAT|O_APPEND, 0644);
  if (fd < 0)
    return -1;

  sprintf(str, "%s %d %d\n", inet_ntoa(address->sin_addr), port, (int)time(NULL));
  write(fd, str, strlen(str));
  close(fd);

  return 0;
}
#endif

static int server_main(int s, int port, param_t *p)
{
  int ret;
  int sockt;
  struct sockaddr_in address;
  socklen_t len;

  signal(SIGCHLD, sigchld_handler);

  while (1) {
    memset(&address, 0, sizeof(address));
    len = sizeof(struct sockaddr_in);
    sockt = accept(s, (struct sockaddr *)&address, &len);
    if (sockt < 0) {
      continue;
    }
#ifdef CONNECT_LIMIT
    if (check_connect_limit(&address) < 0)
      ret = 0;
    else
#endif
    {
#ifdef LOGGING_CONNECT_FROM
      logging_connect(&address, port);
#endif
      ret = server_proc(sockt, p);
    }
    close(sockt);
    if (ret < 0)
      break;
  }

  return 0;
}

static int help()
{
  fprintf(stderr, "simple-inetd <address> <port> <uid> <gid> <dir> <command> [<arg0>...]\n");
  exit(1);
}

int main(int argc, char *argv[], char *envp[])
{
  int port, s, uid;
  in_addr_t addr;
  param_t param;
#ifndef HANDOVER_ENVVAL
  char *null_args[] = { NULL };
#endif

  srand(time(NULL));

  uid = getuid();
#if !defined(NO_CHANGE_ROOTDIR) || !defined(NO_CHANGE_USER)
  if (uid != 0) {
    fprintf(stderr, "You need execute this program as root.\n");
    exit(1);
  }
#endif

  if (argc < 7) {
    help();
  }
  argc--; argv++;

  if (!strcmp(*argv, "any")) {
    addr = INADDR_ANY;
  } else if (!strcmp(*argv, "localhost")) {
    addr = INADDR_LOOPBACK;
  } else {
    addr = ntohl(inet_addr(*argv));
  }
  argc--; argv++;

  port          = atoi(*argv); argc--; argv++;
  param.uid     = atoi(*argv); argc--; argv++;
  param.gid     = atoi(*argv); argc--; argv++;
  param.dir     = *argv;       argc--; argv++;
  param.command = *argv;       argc--; argv++;
  param.argc = argc;
  param.argv = argv;

#ifdef HANDOVER_ENVVAL
  param.envp = envp;
#else
  param.envp = null_args;
#endif

  s = create_socket(addr, port);
  server_main(s, port, &param);

  return 0;
}
