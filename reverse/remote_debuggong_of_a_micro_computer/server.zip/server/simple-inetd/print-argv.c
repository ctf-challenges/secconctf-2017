#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[], char *envp[])
{
  int i;

  printf("argv[]:\n");
  for (i = 0; i < argc; i++) {
    printf("\targv[%d] = %s\n", i, argv[i]);
  }

  printf("envp[]:\n");
  for (i = 0; envp[i]; i++) {
    printf("\tenvp[%d] = %s\n", i, envp[i]);
  }

  fprintf(stdout, "print to stdout.\n");
  fprintf(stderr, "print to stderr.\n");

  write(1, "write to stdout.\n", 17);
  write(2, "write to stderr.\n", 17);

  return 0;
}
