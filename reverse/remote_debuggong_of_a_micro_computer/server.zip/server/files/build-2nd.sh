#!/bin/sh

LANG=C

date

. /home/user/server/files/param.sh

################################################################
# Install tools.

# Basic tools
yum -y install tcsh bash man screen
yum -y install less nano vim
yum -y install patch
yum -y install zip unzip tar gzip
#yum -y install emacs

# Development tools
yum -y install make gcc gdb perl
yum -y install ncurses-devel glibc-static texinfo

# Network tools
yum -y install w3m wget lftp telnet
yum -y install netcat nc
#yum -y install wireshark

# Web server
yum -y install httpd

# for EasyCTF
#yum -y install perl-CGI
#yum -y install perl-CGI-Session
#yum -y install gnuplot
#yum -y install ImageMagick

yum -y update

################################################################
# Shutdown

date

init 0
