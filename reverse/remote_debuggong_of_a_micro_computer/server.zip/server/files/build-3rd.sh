#!/bin/sh

LANG=C

date

. /home/user/server/files/param.sh

################################################################
# Setting passwords

#passwd root
#passwd user

################################################################
# Make users
# Not set password. If password is not set, the user cannot login.

cd $homedir

groupadd -g 10000 arch

for u in $allusers; do
    archparam $u
    useradd -u $uid -d /home/$user -g arch -c $user -m $user
#    chown root:wheel /home/$user
#    chmod 755 /home/$user
    mkdir /home/$user/bin
    mkdir /home/$user/lib
    mkdir /home/$user/tmp
    chmod 777 /home/$user/tmp
    touch /home/$user/tmp/.nodelete
    chattr +i /home/$user/tmp/.nodelete
done

################################################################
# Setup flag file

cd $homedir

for u in $users; do
    archparam $u
    if [ "$word" = yes ]; then
        printf "SECCON{" > /home/$user/word.txt
        cat $serverdir/attack-keyword.txt | grep ^$user: \
            | cut -d : -f 2 | perl -pe 's/\n//' >> /home/$user/word.txt
        printf "}\n" >> /home/$user/word.txt
    else
        echo "BAD LUCK NO KEYWORD" > /home/$user/word.txt
    fi
    chown $user:arch /home/$user/word.txt
    chattr +i /home/$user/word.txt
done

################################################################
# Setup directory

cd $homedir

mkdir /home/lib
mkdir /home/bin
mkdir /home/bin/gdb
mkdir /home/bin/exec

cp /bin/sh /home/bin
cp /bin/sleep /home/bin
cp $serverdir/files/rungdb.sh /home/bin

cp /lib/ld-linux.so.*   /home/lib
#cp /lib/linux-gate.so.* /home/lib
cp /lib/libc.so.*       /home/lib
cp /lib/libm.so.*       /home/lib
cp /lib/libnsl.so.*     /home/lib
cp /lib/libncurses.so.* /home/lib
cp /lib/libdl.so.*      /home/lib
cp /lib/libtinfo.so.*   /home/lib
cp /lib/libz.so.*       /home/lib
cp /lib/libutil.so.*    /home/lib
cp /lib/libgcc_s.so.*   /home/lib
cp /usr/lib/libstdc++.so.* /home/lib

cp $homedir/cross-gcc4/exec/*.x /home/bin/exec

################################################################
# Setup GDB

cd $homedir

cp tools/gdb/bin/*-gdb /home/bin/gdb
cp tools/gdb/bin/*-run /home/bin/gdb

################################################################
# Fix files

cd $homedir

chattr +i /home/bin/*/*
chattr +i /home/bin/* /home/lib/*
chattr +i /home/bin /home/lib

################################################################
# Setup iptables

cd $homedir

cp /etc/sysconfig/iptables /etc/sysconfig/iptables.orig
cat /etc/sysconfig/iptables.orig \
    | $tocomment - - 0 0 "#" ^COMMIT \
    | $tocomment - - 0 0 "#" REJECT \
    > /etc/sysconfig/iptables

#echo "-A INPUT -m state --state NEW -m tcp -p tcp --dport 80 -j ACCEPT" \
#    >> /etc/sysconfig/iptables
echo "-A INPUT -m state --state NEW -m hashlimit -p tcp --dport 80 --hashlimit-name http --hashlimit 1/s --hashlimit-burst 10 --hashlimit-mode srcip --hashlimit-srcmask 24 --hashlimit-htable-expire 10000 -j ACCEPT" \
    >> /etc/sysconfig/iptables

#echo "-A INPUT -m state --state NEW -m tcp -p tcp --dport 12345 -j ACCEPT" \
#    >> /etc/sysconfig/iptables

for u in $allusers; do
    archparam $u
#    echo "-A INPUT -m state --state NEW -m tcp -p tcp --dport $port -j ACCEPT" \
#        >> /etc/sysconfig/iptables
    echo "-A INPUT -m state --state NEW -m hashlimit -p tcp --dport $port --hashlimit-name port$port --hashlimit 1/s --hashlimit-burst 3 --hashlimit-mode srcip --hashlimit-srcmask 24 --hashlimit-htable-expire 10000 -j ACCEPT" \
        >> /etc/sysconfig/iptables
done

echo "-A INPUT -j REJECT --reject-with icmp-host-prohibited" \
    >> /etc/sysconfig/iptables
echo "-A FORWARD -j REJECT --reject-with icmp-host-prohibited" \
    >> /etc/sysconfig/iptables
echo COMMIT >> /etc/sysconfig/iptables

################################################################
# Setup SSH

cd $homedir

cp /etc/ssh/sshd_config /etc/ssh/sshd_config.orig
cat /etc/ssh/sshd_config.orig \
    | $tocomment - - 0 0 "#" ^PermitRootLogin \
    | $tocomment - - 0 0 "#" ^PasswordAuthentication \
    | $tocomment - - 0 0 "#" ^PermitEmptyPasswords \
    | $tocomment - - 0 0 "#" ^ChallengeResponseAuthentication \
    > /etc/ssh/sshd_config
echo "PermitRootLogin no" >> /etc/ssh/sshd_config
echo "PasswordAuthentication no" >> /etc/ssh/sshd_config
echo "PermitEmptyPasswords no" >> /etc/ssh/sshd_config
echo "ChallengeResponseAuthentication yes" >> /etc/ssh/sshd_config
echo "AllowUsers user" >> /etc/ssh/sshd_config

chkconfig iptables on
chkconfig sshd on

################################################################
# Setup httpd

cd $homedir

cp $serverdir/files/index.html /var/www/html
echo "Contents of flag.txt" > /var/www/html/flag.txt.orig
cp /var/www/html/flag.txt.orig /var/www/html/flag.txt

cp $archivedir/gdb-7.12.tar.gz /var/www/html
cp $archivedir/cross-gcc4-20130826.zip /var/www/html

chkconfig httpd on

################################################################
# Setup boot

cd $homedir

echo "/home/user/server/files/mount.sh" >> /etc/rc.local
echo "/home/user/server/files/run.sh &" >> /etc/rc.local

################################################################
# Shutdown

date

init 0
