#!/usr/bin/perl

$fromfile = shift(@ARGV);
$tofile   = shift(@ARGV);
$bcount   = shift(@ARGV);
$fcount   = shift(@ARGV);
$comment  = shift(@ARGV);
@keywords = @ARGV;

if ($fromfile eq "-") {
	$infile = *STDIN
} else {
	open($infile, "< $fromfile") || die "file not found.";
}

$num = 0;
while (<$infile>) {
	$line[$num] = $_;
	$num++;
}

for ($i = 0; $i < $num; $i++) {
	$check[$i] = 0;
}

for ($i = 0; $i < $num; $i++) {
	foreach (@keywords) {
		if ($line[$i] =~ /$_/) {
			$from = $i - $bcount;
			$to   = $i + $fcount;
			if ($from < 0) {
				$from = 0;
			}
			if ($to > $num - 1) {
				$to = $num - 1;
			}
			for ($j = $from; $j <= $to; $j++) {
				$check[$j] = 1;
			}
		}
	}
}

if ($tofile eq "-") {
	$outfile = *STDOUT
} else {
	open($outfile, "> $tofile");
}

for ($i = 0; $i < $num; $i++) {
	if ($check[$i]) {
		print $outfile "$comment";
	}
	print $outfile "$line[$i]";
}
