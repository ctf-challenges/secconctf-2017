#!/bin/sh

. /home/user/server/files/param.sh

for user in $alluserlist; do
    umount /home/$user/bin
    umount /home/$user/lib
done
