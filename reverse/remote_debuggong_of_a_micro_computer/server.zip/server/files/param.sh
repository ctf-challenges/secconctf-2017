#!/bin/sh

homedir=/home/user
serverdir=$homedir/server
archivedir=$homedir/archive
cross=$homedir/cross-gcc4

toolsdir=$homedir/tools
gdbdir=$toolsdir/gdb

tocomment=$serverdir/files/tocomment.pl

archs=""

# Enable architectures
archs="$archs ARM:arm-elf:cross:yes:enable"
archs="$archs H8:h8300-elf:cross:yes:enable"
archs="$archs SH:sh-elf:cross:yes:enable"
archs="$archs V850:v850-elf:cross:yes:enable"

# Enable architectures, but these are disable for the game balance
archs="$archs PowerPC:powerpc-elf:cross:no:disable"
archs="$archs Blackfin:bfin-elf:cross:no:disable"
archs="$archs M32C:m32c-elf:cross:no:disable"
archs="$archs FR-V:frv-elf:cross:no:disable"
archs="$archs MN10300:mn10300-elf:cross:no:disable"
archs="$archs Thumb:arm16-elf:cross:no:disable"

# The program runs normally, but cannot connect GDB server normally
archs="$archs M32R:m32r-elf:cross:no:disable"

# Cannot run the program normally on GDB
# MIPS: RSVD_INSTRUCTION(interp.c) is changed from 0x00000005 to 0x00000039.
# RX:   Core dump at starting GDB.
# CRIS: Cannot select simulator for target.
archs="$archs MIPS:mips-elf:cross:no:disable"
archs="$archs RX:rx-elf:cross:no:disable"
archs="$archs CRIS:cris-elf:cross:no:disable"
archs="$archs MIPS16:mips16-elf:cross:no:disable"

# Cannot build GDB
archs="$archs MicroBlaze:microblaze-elf:cross:no:disable"
archs="$archs RL78:rl78-elf:cross:no:disable"
archs="$archs AVR:avr-elf:cross:no:disable"
archs="$archs SH64:sh64-elf:cross:no:disable"
archs="$archs SPARC:sparc-elf:cross:no:disable"

archparam()
{
    user=`echo $1 | cut -d : -f 1`
    uid=`echo $1 | cut -d : -f 2`
    port=`echo $1 | cut -d : -f 3`
    name=`echo $1 | cut -d : -f 4`
    arch=`echo $1 | cut -d : -f 5`
    path=`echo $1 | cut -d : -f 6`
    word=`echo $1 | cut -d : -f 7`
    enable=`echo $1 | cut -d : -f 8`
}

allusers=""
alluserlist=""
n=0
for a in $archs; do
    user=`printf arch%02d $n`
    uid=`expr $n + 10000`
    port=`expr $n + 10000`
    allusers="$allusers $user:$uid:$port"
    alluserlist="$alluserlist $user"
    n=`expr $n + 1`
done

users=""
userlist=""
n=0
for a in $archs; do
    enable=`echo $a | cut -d : -f 5`
    if [ "$enable" = "enable" ]; then
	user=`printf arch%02d $n`
	uid=`expr $n + 10000`
	port=`expr $n + 10000`
	users="$users $user:$uid:$port:$a"
	userlist="$userlist $user"
	n=`expr $n + 1`
    fi
done
