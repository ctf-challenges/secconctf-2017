#!/usr/bin/perl
#
# Example:
# incsize.pl /var/www/html info.html flag.txt \
#         10000 /home arch0 arch1 arch2 arch3 arch4

$interval = 3;
@size_list = (
#5000, 4000, 3000, 2500, 2000, 1500, 1400, 1300, 1200, 1100, 1000,  950,
                         5000, 5000, 5000, 5000, 5000, 3000, 2000, 1000,
  900,  850,  800,  750,  700,  650,  600,  580,  560,  540,  520,  500,
  480,  470,  460,  450,  440,  430,  420,  410,  400,  390,  380,  370,
  360,  350,  340,  330,  320,  310,  300,  290,  280,  270,  260,  250,
  240,  230,  220,  210,  200,  190,  180,  170,  160,  150,  140,  130,
  120,  110,  100,   95,   90,   85,   80,   75,   70,   65,   60,   55,
   50,   48,   46,   44,   42,   40,   38,   36,   34,   32,   30,   28,
   26,   24,   22,   20,   18,   16,   14,   12,   10,    8,    6,    4,
);

$htmldir   = shift(@ARGV);
$infofile  = shift(@ARGV);
$flagfile  = shift(@ARGV);
$startport = shift(@ARGV);
$homedir   = shift(@ARGV);

while (defined($_ = shift(@ARGV))) {
	push(@users, $_);
}

while (1) {
	while (1) {
		$t = time;
		($sec, $min) = localtime($t);
		if ((($min % 5) == 4) && ($sec >= 40)) {
			last;
		}
		$i = int((($min % 5) * 60 + $sec) / $interval);
		if ($i < @size_list) {
			$size = $size_list[$i];
		} else {
			$size = $size_list[@size_list - 1];
		}
		write_file("/tmp/size.txt", "$size\n");
		mkinfo("$htmldir/$infofile", $size, $homedir, @users);
		sleep(1);
	}
	mkflag("$htmldir/$flagfile", $homedir, @users);
	while (1) {
		$t = time;
		($sec, $min) = localtime($t);
		if ((($min % 5) == 0) && ($sec >= 10)) {
			last;
		}
		write_file("/tmp/size.txt", "$size\n");
		mkinfo("$htmldir/$infofile", $size, $homedir, @users);
		sleep(1);
        }
}

sub write_file {
	my $file;
	my $lines;

	($file, $lines) = @_;
	open(FILE, "> ${file}.new");
	print FILE "$lines";
	close(FILE);
	system("mv ${file}.new $file");
}

sub readflag {
	my $file;
	my $flag;

	($file) = @_;

	$flag = "NOFILE";
	if (open(FILE, "< $file")) {
		$flag = <FILE>;
		$flag =~ s/\s+//g;
		if ($flag eq "") {
			$flag = "EMPTY";
		} elsif ($flag =~ /[^0-9a-fA-F]/) {
			$flag = "INVALID";
		}
	}

	return $flag;
}

sub mkinfo {
	my $file;
	my $size;
	my $homedir;
	my @users;
	my $lines;
	my $user;
	my $flag;

	($file, $size, $homedir, @users) = @_;

	$lines  = "";

	$lines .= "<html><body>\n";
	$lines .= "<center>\n";
	$lines .= "<h2>\n";
	$lines .= "Limit of size is $size\n";
	$lines .= "</h2>\n";
	$lines .= "<p>\n";
	$lines .= "<h3>\n";

	$lines .= "List of Servers\n";
	$lines .= "<table border=1>\n";
	$lines .= "<tr><th>Name</th><th>Port</th><th>Flag</th></tr>\n";

	$port = $startport;
	foreach $user (@users) {
		$flag = readflag("$homedir/$user/flag.txt");
		$lines .= "<tr><td>$user</td><td>$port</td><td>$flag</td></tr>\n";
		$port++;
	}

	$lines .= "</table>\n";
	$lines .= "</h3>\n";
	$lines .= "</center>\n";
	$lines .= "</body></html>\n";

	write_file($file, $lines);
}


sub mkflag {
	my $file;
	my $homedir;
	my @users;
	my $lines;
	my $user;
	my $flag;

	($file, $homedir, @users) = @_;

	$lines  = "";

	foreach $user (@users) {
		$flag = readflag("$homedir/$user/flag.txt");
		if (($flag ne "NOFILE") && ($flag ne "EMPTY") &&
			($flag ne "INVALID")) {
			$lines .= "$flag\n";
		}
	}

	if ($lines ne "") {
		open(FILE, ">> $file");
		print FILE "$lines";
		close(FILE);
	}
}
