#!/bin/sh

port=$1
shift 1
limit=$1
shift 1
gdb=$1
shift 1
exec=$1
shift 1
args=$*

cmdfile=/tmp/command-$port

echo "target sim $args" >  $cmdfile
echo "load" >> $cmdfile
echo "serverrun 0.0.0.0:$port" >> $cmdfile

# In background process, for GDB to avoid stopping by closing the
# standard input, run sleep as dummy and maintain the standard input of GDB.
/bin/sleep $limit | $gdb -x $cmdfile $exec > /tmp/gdb-$port.log 2>&1
