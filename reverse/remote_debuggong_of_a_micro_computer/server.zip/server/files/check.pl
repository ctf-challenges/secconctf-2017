#!/usr/bin/perl
#
# Example:
# check.pl /tmp/simple-inetd.log 1 10000 /home arch0 arch1 arch2 arch3 arch4

$logfile   = shift(@ARGV);
$interval  = shift(@ARGV);
$startport = shift(@ARGV);
$homedir   = shift(@ARGV);

$commit_command = "/home/user/commit.sh";

while (defined($_ = shift(@ARGV))) {
	push(@users, $_);
}

$old_size = 0;
if (-f $logfile) {
	$old_size = -s $logfile;
}
foreach $user (@users) {
	$f = "$homedir/$user/flag.txt";
	if (-f $f) {
		$d = (stat $f)[9];
		$mdate{$user} = $d;
	}
}

while (1) {
	sleep($interval);

	if (! -f $logfile) {
		next;
	}

	$size = -s $logfile;
	if ($size != $old_size) {
		if ($size > $old_size) {
			$diffsize = $size - $old_size;
			@_ = `cat $logfile | tail -c $diffsize`;
			foreach (@_) {
				($ipaddr, $port, $t) = split(/\s+/);
				if (($ipaddr eq "") || ($port eq "") || ($t eq "")) {
					next;
				}
				$user = sprintf("arch%02d", $port - $startport);
				command_exec($ipaddr, $port, $user, $t, 0);
			}
		}
		$old_size = $size;
	}

	foreach $user (@users) {
		$f = "$homedir/$user/flag.txt";
		$d = (stat $f)[9];
		if ($mdate{$user} != $d) {
			$mdate{$user} = $d;
			($port) = $user =~ /arch(\d+)/;
			$port += $startport;
			$_ = `cat $logfile | grep " $port " | tail -n 1`;
			if ($_ ne "") {
				($ipaddr, $port, $t) = split(/\s+/);
				if (($ipaddr eq "") || ($port eq "") || ($t eq "")) {
					next;
				}
				$t = time(); # Same as simple-inetd
#				$t = $d;
				command_exec($ipaddr, $port, $user, $t, 1);
			}
		}
	}
}

sub command_exec {
	my $ipaddr;
	my $port;
	my $user;
	my $t;
	my $succeed;
	my $cmd;

	($ipaddr, $port, $user, $t, $succeed) = @_;

	if (-x "$commit_command") {
		system("$commit_command $ipaddr $port $user $t $succeed");
	}

#	print "$ipaddr, $port, $user, $t, $succeed\n";
}
