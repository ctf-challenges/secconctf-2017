#!/bin/sh

LANG=C

date

. /home/user/server/files/param.sh

################################################################
# Cleaning

cd $homedir

rm -fR cross-gcc4
rm -fR simple-inetd
rm -fR timer-exec
rm -fR cross-gdb
rm -fR $toolsdir

################################################################
# Make directory

cd $homedir

mkdir -p $archivedir
mkdir -p $toolsdir
mkdir -p $gdbdir

################################################################
# Download tools

cd $homedir

if [ ! -f $archivedir/gdb-7.12.tar.gz ]; then
    cd $archivedir ; wget -nd http://www2.kozos.jp/tools/gdb-7.12.tar.gz
fi
if [ ! -f $archivedir/cross-gcc4-20130826.zip ]; then
    cd $archivedir ; wget -nd http://kozos.jp/books/asm/cross-gcc4-20130826.zip
fi
if [ ! -f $archivedir/pkttools-1.16.zip ]; then
    cd $archivedir ; wget -nd http://kozos.jp/software/pkttools-1.16.zip
fi

################################################################
# Build tools

cd $homedir

cp -R $serverdir/cross-gcc4 $homedir

cp -R $serverdir/simple-inetd $homedir
cp -R $serverdir/timer-exec   $homedir
cd $homedir/simple-inetd ; make clean ; make
cd $homedir/timer-exec   ; make clean ; make

################################################################
# Build GDB

cd $homedir

cp -R $serverdir/cross-gdb $homedir

if [ -f $archivedir/gdb-7.12.tar.gz ]; then
    cp $archivedir/gdb-7.12.tar.gz $homedir/cross-gdb/toolchain/orig
fi

# Setup

cd $homedir/cross-gdb/toolchain ; ./fetch.sh ; ./setup.sh

# Build

cd $homedir/cross-gdb/build ; ./build-install-clean-all.sh

################################################################
# Shutdown

date

sudo shutdown -h now
