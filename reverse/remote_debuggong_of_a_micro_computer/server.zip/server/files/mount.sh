#!/bin/sh

. /home/user/server/files/param.sh

for user in $alluserlist; do
    mount --bind /home/bin /home/$user/bin
    mount --bind /home/lib /home/$user/lib
done
