#!/bin/sh

#. /home/user/server/files/param.sh
. ./param.sh

echo "All Users:"
echo $allusers

echo
echo "Enable Users:"
echo $users

echo
echo "All User List:"
echo $alluserlist

echo
echo "Enable User List:"
echo $userlist
