#!/bin/sh

. /home/user/server/files/param.sh

inetd=$homedir/simple-inetd/simple-inetd
timerdir=$homedir/timer-exec
timer=timer-exec
startport=10000
gid=10000
limit=30

/home/user/server/files/check.pl /tmp/simple-inetd.log 3 $startport /home $userlist &
/home/user/server/files/incsize.pl /var/www/html info.html flag.txt $startport /home $userlist &

for u in $users; do
    archparam $u

    opt=
    gdb=$arch-gdb
    case $arch in
	powerpc-elf) opt="-e linux" ;;
	bfin-elf)    opt="--environment user" ;;
	arm16-elf)   gdb="arm-elf-gdb" ;;
    esac

    $inetd any $port 0 0 $timerdir $timer \
	$timer $limit 9 $uid $gid /home/$user /bin/rungdb.sh \
	rungdb.sh RANDPORT $limit /bin/gdb/$gdb /bin/exec/$arch.x $opt &
done
