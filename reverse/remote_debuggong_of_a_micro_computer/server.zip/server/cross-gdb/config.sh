#!/bin/sh

install_dir="/home/user/tools/gdb"

#binutils="binutils-2.23.1"
#gcc="gcc-4.7.2"
#newlib="newlib-1.20.0"
#gdb="gdb-7.5.1"
gdb="gdb-7.12"

#gmp="gmp-5.1.1"
#mpfr="mpfr-3.1.2"
#mpc="mpc-1.0.1"

#makeopt="-j 2"
