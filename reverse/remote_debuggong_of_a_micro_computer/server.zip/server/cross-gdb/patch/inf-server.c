/* Generic simulator server. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include "defs.h"
#include "arch-utils.h"
#include "target.h"

#include "inf-server.h"

/* Generic server */

static int server_socket = -1;

int
inferior_server_is_active ()
{
  return server_socket != -1;
}

int
inferior_server_socket ()
{
  return server_socket;
}

int
inferior_server_open (char *hostname, int port)
{
  struct sockaddr_in addr;
  socklen_t addrlen;
  struct hostent *host = NULL;
  int s = -1, on = 1;

  if (hostname)
    {
      host = gethostbyname(hostname);
      if (host == NULL)
	return -1;
    }

  s = socket(PF_INET, SOCK_STREAM, 0);
  if (s < 0)
    goto err;

  if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
    goto err;

  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  if (hostname)
    {
      memcpy(&addr.sin_addr, host->h_addr, host->h_length);
    }
  else
    {
      addr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
  addrlen = sizeof(addr);

  if (bind(s, (struct sockaddr *)&addr, addrlen) < 0)
    goto err;

  if (listen(s, 5) < 0)
    goto err;

  memset(&addr, 0, sizeof(addr));
  addrlen = sizeof(addr);
  server_socket = accept(s, (struct sockaddr *)&addr, &addrlen);
  if (server_socket < 0)
    goto err;

  close(s);
  return 1;

err:
  if (s >= 0)
    close(s);
  return 0;
}

int
inferior_server_close ()
{
  shutdown(server_socket, SHUT_RDWR);
  close(server_socket);
  server_socket = -1;
  return 0;
}

enum {
  STUB_SIGHUP  =  1,
  STUB_SIGILL  =  4,
  STUB_SIGTRAP =  5,
  STUB_SIGEMT  =  7,
  STUB_SIGBUS  = 10,
  STUB_SIGSEGV = 11,
};

#define BUFFER_SIZE 2048
static unsigned char recvbuf[BUFFER_SIZE];
static unsigned char sendbuf[BUFFER_SIZE];

static int num_regs;
static int size_regs;
static unsigned char *registers = NULL;

static void putDebugChar(unsigned char c)
{
  write(server_socket, &c, 1);
}

static int getDebugChar()
{
  unsigned char c;
  if (read(server_socket, &c, 1) != 1)
    return -1;
  return c;
}

static int a2h(unsigned char c)
{
  if ((c >= '0') && (c <= '9'))
    return c - '0';
  if ((c >= 'a') && (c <= 'f'))
    return c - 'a' + 10;
  if ((c >= 'A') && (c <= 'F'))
    return c - 'A' + 10;
  return -1;
}

static unsigned char h2a(int val)
{
  if ((val >= 0) && (val < 16))
    return "0123456789abcdef"[val];
  return '\0';
}

static int expand(unsigned char *buffer, int size, int bufsize)
{
  int n, i;
  unsigned char *p;

  while (1) {
    n = -1;
    for (p = buffer + 1; p - buffer < size; p++) {
      if (*p == '*') {
        n = *(p + 1) - 29;
        break;
      }
    }
    if (n < 0)
      break;
    if (n - 2 + size >= bufsize)
      return -1;
    memmove(p + n - 2, p, size - (p - buffer));
    for (i = 0; i < n; i++)
      *(p + i) = *(p - 1);
    size += n - 2;
  }

  return size;
}

static unsigned char *stub_puts(unsigned char *buffer)
{
  unsigned char c, sum;
  int i, r;

  while (1) {
    putDebugChar('$');

    i = 0;
    sum = 0;
    while ((c = buffer[i++]) != '\0') {
      putDebugChar(c);
      sum += c;
    }

    putDebugChar('#');
    putDebugChar(h2a((sum >> 4) & 0xf));
    putDebugChar(h2a(sum & 0xf));

    r = getDebugChar();
    if ((r < 0) || (r == '+'))
      break;
  }

  return buffer;
}

static int stub_getc(unsigned char *buffer, int bufsize)
{
  static int size = 0;
  static unsigned char sum = 0, datasum = 0;
  unsigned char c = 0;
  int r;
  static enum {
    GETS_STATUS_WAIT_DOLLAR,
    GETS_STATUS_READ_DATA,
    GETS_STATUS_READ_SUM_UPPER,
    GETS_STATUS_READ_SUM_LOWER,
    GETS_STATUS_END,
  } status = GETS_STATUS_WAIT_DOLLAR;

  if (buffer == NULL) {
    status = GETS_STATUS_WAIT_DOLLAR;
    return 0;
  }

  if (status != GETS_STATUS_END) {
    r = getDebugChar();
    c = r;
    if (r < 0) { /* socket is closed */
      return -1;
    } else if (c == 0x03) { /* Ctrl+C */
      kill(getpid(), SIGINT);
    } else if (c == '-') {
      stub_puts(sendbuf);
    } else if (c == '$') {
      size = 0;
      sum = datasum = 0;
      status = GETS_STATUS_READ_DATA;
    } else {
      switch (status) {
      case GETS_STATUS_WAIT_DOLLAR:
	break;
      case GETS_STATUS_READ_DATA:
	if (c == '#') {
	  status = GETS_STATUS_READ_SUM_UPPER;
	  break;
	}
	sum += c;
	buffer[size++] = c;
	if (size >= bufsize) {
	  status = GETS_STATUS_WAIT_DOLLAR;
	}
	break;
      case GETS_STATUS_READ_SUM_UPPER:
	datasum = a2h(c) << 4;
	status = GETS_STATUS_READ_SUM_LOWER;
	break;
      case GETS_STATUS_READ_SUM_LOWER:
	datasum |= a2h(c);
	if (sum != datasum) {
	  putDebugChar('-');
	  status = GETS_STATUS_WAIT_DOLLAR;
	} else {
	  putDebugChar('+');
	  status = GETS_STATUS_END;
	}
	break;
      default:
	break;
      }
    }
  }

  if (status != GETS_STATUS_END)
    return 0;

  return size;
}

static unsigned char *stub_gets(unsigned char *buffer, int bufsize)
{
  int size;

  while (1) {
    size = stub_getc(buffer, bufsize);
    if (size < 0)
      return NULL;
    if (size > 0) {
      stub_getc(NULL, 0);
      size = expand(buffer, size, bufsize);
      if (size > 0)
	break;
    }
  }

  buffer[size] = '\0';

  if ((size > 2) && (buffer[2] == ':')) {
    putDebugChar(buffer[0]);
    putDebugChar(buffer[1]);
    return &buffer[3];
  }
  return buffer;
}

static unsigned char *alloc_memory_buffer(int size)
{
  static unsigned char *memory_buffer = NULL;
  static int memory_buffer_size = -1;

  if (size <= 0)
    size = 1;

  if (memory_buffer_size < size) {
    if (memory_buffer)
      free(memory_buffer);
    memory_buffer = (unsigned char *)malloc(size);
    memory_buffer_size = size;
  }

  memset(memory_buffer, 0, memory_buffer_size);

  return memory_buffer;
}

static unsigned char *read_memory(int target, void *host_addr, long target_addr, unsigned char *buffer, int size)
{
  unsigned char c, *p;
  int i;

  if (target) {
    p = alloc_memory_buffer(size);
    target_read_memory (target_addr, (gdb_byte *)p, size);
  } else {
    p = (unsigned char *)host_addr;
  }

  for (i = 0; i < size; i++) {
    c = p[i];
    *(buffer++) = h2a((c >> 4) & 0xf);
    *(buffer++) = h2a(c & 0xf);
  }
  *buffer = 0;

  return buffer;
}

static unsigned char *write_memory(int target, void *host_addr, long target_addr, unsigned char *buffer, int size)
{
  unsigned char c, *p;
  int i;

  if (target) {
    p = alloc_memory_buffer(size);
  } else {
    p = (unsigned char *)host_addr;
  }

  for (i = 0; i < size; i++) {
    if (*buffer == '\0') {
      size = i;
      break;
    }
    c  = a2h(*(buffer++)) << 4;
    c |= a2h(*(buffer++));
    p[i] = c;
  }

  if (target) {
    target_write_memory (target_addr, (gdb_byte *)p, size);
  }

  return buffer;
}

static int a2val(unsigned char **pp, long *valp)
{
  int size = 0;
  long v, val = 0;
  unsigned char *p;

  p = *pp;
  while (1) {
    v = a2h(*p);
    if (v < 0) break;
    val = (val << 4) | v;
    p++;
    size++;
  }
  *valp = val;
  *pp = p;

  return size;
}

static int start_exception()
{
  int sig = STUB_SIGTRAP;
  unsigned char *p;

  p = sendbuf;
  *(p++) = 'T';
  *(p++) = h2a((sig >> 4) & 0xf);
  *(p++) = h2a(sig & 0xf);
  *(p++) = '\0';

  stub_puts(sendbuf);

  return 0;
}

static int reply_exception(struct gdbarch *gdbarch)
{
  int sig = STUB_SIGTRAP;
  unsigned char *p;
  long addr, size;

  if (stub_gets(recvbuf, BUFFER_SIZE) == NULL)
    return INF_SERVER_HANDLE_DETACH;

  sendbuf[0] = '\0'; /* not support */

  p = recvbuf;
  switch (*(p++)) {
  case '?':
    sendbuf[0] = 'S';
    sendbuf[1] = h2a((sig >> 4) & 0xf);
    sendbuf[2] = h2a(sig & 0xf);
    sendbuf[3] = '\0';
    break;

  case 'g':
    if (size_regs * 2 + 1 > BUFFER_SIZE) {
      strcpy((char *)sendbuf, "E03");
      break;
    }
    read_memory(0, registers, 0, sendbuf, size_regs);
    break;

  case 'G':
    write_memory(0, registers, 0, p, size_regs);
    strcpy((char *)sendbuf, "OK");
    break;

  case 'm':
    a2val(&p, &addr);
    if (*(p++) != ',') {
      strcpy((char *)sendbuf, "E01");
      break;
    }
    a2val(&p, &size);
    if (size * 2 + 1 > BUFFER_SIZE) {
      strcpy((char *)sendbuf, "E03");
      break;
    }
    read_memory(1, NULL, addr, sendbuf, size);
    break;

  case 'M':
#if 0
    a2val(&p, &addr);
    if (*(p++) != ',') {
      strcpy((char *)sendbuf, "E01");
      break;
    }
    a2val(&p, &size);
    if (*(p++) != ':') {
      strcpy((char *)sendbuf, "E02");
      break;
    }
    write_memory(1, NULL, addr, p, size);
    strcpy((char *)sendbuf, "OK");
#else
    strcpy((char *)sendbuf, "E03");
#endif
    break;

  case 's':
    return INF_SERVER_HANDLE_STEP;

  case 'c':
    return INF_SERVER_HANDLE_CONTINUE;

  case 'D':
  case 'k':
    return INF_SERVER_HANDLE_DETACH;

  default:
    break;
  }
  stub_puts(sendbuf);

  return INF_SERVER_HANDLE_NORMAL;
}

static int handle_exception(struct gdbarch *gdbarch)
{
  int step;

  do {
    step = reply_exception(gdbarch);
  } while (step == INF_SERVER_HANDLE_NORMAL);

  return step;
}

static int interrupt_count = 0;

int
inferior_server_init (int start_count)
{
  struct gdbarch *gdbarch = get_current_arch ();
  int regnum, s;

  /* See remote.c:map_regcache_remote_table () */

  num_regs = 0;
  size_regs = 0;

  for (regnum = 0; regnum < gdbarch_num_regs (gdbarch); regnum++)
    {
      s = register_size (gdbarch, regnum);
      if (s != 0)
	{
	  num_regs++;
	  size_regs += s;
	}
    }

  registers = (unsigned char *)malloc(size_regs);

  interrupt_count = start_count;

  return 0;
}

static void store_registers(struct gdbarch *gdbarch, struct regcache *regcache)
{
  int i;
  int regnum, regnum_pnum_min, pnum, pnum_min, pnum_prev = -1;
  int offset = 0;

  memset(registers, 0, size_regs);

  /* See remote.c:store_registers_using_G() */
  for (i = 0; i < num_regs; i++)
    {
      pnum_min = -1;
      for (regnum = 0; regnum < gdbarch_num_regs (gdbarch); regnum++)
	{
	  if (register_size (gdbarch, regnum) == 0)
	    continue;
	  pnum = gdbarch_remote_register_number (gdbarch, regnum);
	  if (pnum <= pnum_prev)
	    continue;
	  if (pnum_min >= 0 && pnum >= pnum_min)
	    continue;
	  regnum_pnum_min = regnum;
	  pnum_min = pnum;
	}
      regnum = regnum_pnum_min;
      pnum = pnum_min;

      regcache_raw_collect (regcache, regnum, registers + offset);

      pnum_prev = pnum;
      offset += register_size (gdbarch, regnum);
    }
}

static void restore_registers(struct gdbarch *gdbarch, struct regcache *regcache)
{
  int i;
  int regnum, regnum_pnum_min, pnum, pnum_min, pnum_prev = -1;
  int offset = 0;

  /* See remote.c:process_g_packet() */
  for (i = 0; i < num_regs; i++)
    {
      pnum_min = -1;
      for (regnum = 0; regnum < gdbarch_num_regs (gdbarch); regnum++)
	{
	  if (register_size (gdbarch, regnum) == 0)
	    continue;
	  pnum = gdbarch_remote_register_number (gdbarch, regnum);
	  if (pnum <= pnum_prev)
	    continue;
	  if (pnum_min >= 0 && pnum >= pnum_min)
	    continue;
	  regnum_pnum_min = regnum;
	  pnum_min = pnum;
	}
      regnum = regnum_pnum_min;
      pnum = pnum_min;

      regcache_raw_supply (regcache, regnum, registers + offset);

      pnum_prev = pnum;
      offset += register_size (gdbarch, regnum);
    }
}

int
inferior_server_interrupt ()
{
  if (!inferior_server_is_active())
    return -1;

  if (interrupt_count++ == 0)
    return 0;

  start_exception();
  return 0;
}

int
inferior_server_handle ()
{
  struct gdbarch *gdbarch = get_current_arch ();
  struct regcache *regcache = get_current_regcache ();
  int regnum, size, r;

  size = stub_getc(recvbuf, BUFFER_SIZE);
  if (size < 0)
    return INF_SERVER_HANDLE_DETACH;
  if (size == 0)
    return INF_SERVER_HANDLE_NORMAL;

  gdbarch = get_current_arch ();
  regcache = get_current_regcache ();

  for (regnum = 0; regnum < num_regs; regnum++)
    target_fetch_registers (regcache, regnum);

  store_registers(gdbarch, regcache);
#if 1
  r = reply_exception(gdbarch);
#else
  r = handle_exception(gdbarch);
#endif
  restore_registers(gdbarch, regcache);

  for (regnum = 0; regnum < num_regs; regnum++)
    target_store_registers (regcache, regnum);

  return r;
}
