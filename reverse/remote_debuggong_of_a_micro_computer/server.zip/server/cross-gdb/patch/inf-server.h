enum {
  INF_SERVER_HANDLE_NORMAL,
  INF_SERVER_HANDLE_STEP,
  INF_SERVER_HANDLE_CONTINUE,
  INF_SERVER_HANDLE_DETACH,
};

int inferior_server_is_active ();
int inferior_server_socket ();
int inferior_server_open (char *hostname, int port);
int inferior_server_close ();
int inferior_server_init (int start_count);
int inferior_server_interrupt ();
int inferior_server_handle ();
