--- gdb/infrun.c.orig	2016-10-08 02:09:21.000000000 +0900
+++ gdb/infrun.c	2017-01-22 15:40:45.688694000 +0900
@@ -64,6 +64,7 @@
 #include "event-loop.h"
 #include "thread-fsm.h"
 #include "common/enum-flags.h"
+#include "inf-server.h"
 
 /* Prototypes for local functions */
 
@@ -3640,6 +3641,19 @@
   else
     event_ptid = target_wait (ptid, status, options);
 
+  /*
+   start_event_loop()
+   -> gdb_do_one_event()
+   -> check_async_event_handlers()
+   -> (*async_handler_ptr->proc)()
+   -> infrun_async_inferior_event_handler()
+   -> inferior_event_handler(INF_REG_EVENT, NULL)
+   -> fetch_inferior_event()
+   -> do_target_wait()
+   -> target_wait()
+   */
+  inferior_server_interrupt ();
+
   return event_ptid;
 }
 
