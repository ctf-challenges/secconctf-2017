--- sim/sh/interp.c.orig	2016-08-02 00:50:21.000000000 +0900
+++ sim/sh/interp.c	2017-01-24 22:39:46.216784000 +0900
@@ -899,9 +899,11 @@
 	  {
 
 #if !defined(__GO32__) && !defined(_WIN32)
+#if 0
 	  case SYS_fork:
 	    regs[0] = fork ();
 	    break;
+#endif
 /* This would work only if endianness matched between host and target.
    Besides, it's quite dangerous.  */
 #if 0
