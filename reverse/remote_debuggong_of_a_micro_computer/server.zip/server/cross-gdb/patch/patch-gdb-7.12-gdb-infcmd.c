--- gdb/infcmd.c.orig	2016-10-08 02:04:17.000000000 +0900
+++ gdb/infcmd.c	2017-01-22 15:40:45.650513000 +0900
@@ -58,6 +58,7 @@
 #include "thread-fsm.h"
 #include "top.h"
 #include "interps.h"
+#include "inf-server.h"
 
 /* Local functions: */
 
@@ -524,7 +525,7 @@
    running the program.  */
 
 static void
-run_command_1 (char *args, int from_tty, int tbreak_at_main)
+run_command_1 (char *args, int from_tty, int tbreak_at_main, int tbreak_at_entrypoint)
 {
   char *exec_file;
   struct cleanup *old_chain;
@@ -630,6 +631,16 @@
      has done its thing; now we are setting up the running program.  */
   post_create_inferior (&current_target, 0);
 
+  /* Insert the temporary breakpoint if a location was specified.  */
+#if 1
+  if (tbreak_at_entrypoint)
+    {
+      char buf[64];
+      sprintf(buf, "*0x%x", (int)regcache_read_pc (get_current_regcache ()));
+      tbreak_command (buf, 0);
+    }
+#endif
+
   /* Start the target running.  Do not use -1 continuation as it would skip
      breakpoint right at the entry point.  */
   proceed (regcache_read_pc (get_current_regcache ()), GDB_SIGNAL_0);
@@ -642,7 +653,113 @@
 static void
 run_command (char *args, int from_tty)
 {
-  run_command_1 (args, from_tty, 0);
+  run_command_1 (args, from_tty, 0, 0);
+}
+
+static void stepi_command (char *count_string, int from_tty);
+static void continue_command (char *args, int from_tty);
+
+static void
+socket_event_handler (int error, gdb_client_data client_data)
+{
+  switch (inferior_server_handle ()) {
+  case INF_SERVER_HANDLE_STEP:
+#if 1
+    stepi_command (NULL, 0);
+#elif 0
+    execute_command ("stepi", 0);
+#else
+    command_handler ("stepi");
+#endif
+    break;
+  case INF_SERVER_HANDLE_CONTINUE:
+#if 1
+    continue_command (NULL, 0);
+#elif 0
+    execute_command ("continue", 0);
+#else
+    command_handler ("continue");
+#endif
+    break;
+  case INF_SERVER_HANDLE_DETACH:
+    delete_file_handler (inferior_server_socket ());
+    inferior_server_close ();
+    printf_filtered (_("Connection closed\n"));
+    break;
+  default:
+    break;
+  }
+}
+
+static void
+server_command_init (char *server, int from_tty)
+{
+  int port;
+  char *p, *hostname;
+
+  if (inferior_server_is_active ())
+    error (_("Server is already active."));
+
+  if (server == NULL)
+    error (_("No hostname and port number."));
+
+  server = xstrdup(server);
+  printf_filtered (_("Wait to accept at %s\n"), server);
+
+  p = strchr(server, ':');
+  if (p) {
+    *p = '\0';
+    hostname = server;
+    port = atoi(p + 1);
+  } else {
+    hostname = NULL;
+    port = atoi(server);
+  }
+
+  inferior_server_open (hostname, port);
+  printf_filtered (_("Accepted\n"));
+
+  xfree(server);
+
+  add_file_handler (inferior_server_socket (), socket_event_handler, NULL);
+}
+
+static void
+gdbserver_command (char *args, int from_tty)
+{
+  server_command_init (args, from_tty);
+  inferior_server_init (1);
+}
+
+static void
+serverrun_command (char *args, int from_tty)
+{
+  char *p, *server;
+
+  if (args == NULL)
+    error (_("No hostname and port number."));
+
+  server = args;
+  p = args;
+  while (!isspace(*p) && *p != '\0')
+    p++;
+
+  server = (char *)xmalloc(p - args + 1);
+  memcpy(server, args, p - args);
+  server[p - args] = '\0';
+
+  while (isspace(*p) && *p != '\0')
+    p++;
+
+  args = (*p == '\0') ? NULL : p;
+
+  server_command_init (server, from_tty);
+
+  xfree(server);
+
+  inferior_server_init (0);
+
+  run_command_1 (args, from_tty, 0, 1);
 }
 
 /* Start the execution of the program up until the beginning of the main
@@ -658,7 +775,7 @@
     error (_("No symbol table loaded.  Use the \"file\" command."));
 
   /* Run the program until reaching the main procedure...  */
-  run_command_1 (args, from_tty, 1);
+  run_command_1 (args, from_tty, 1, 0);
 } 
 
 static int
@@ -3440,6 +3557,24 @@
 \"run\" command."));
   set_cmd_completer (c, filename_completer);
 
+  c = add_com ("serverrun", class_run, serverrun_command, _("\
+Start debugged program and accept by gdbserver.  You may specify hostname, port, and arguments to give it.\n\
+Args may include \"*\", or \"[...]\"; they are expanded using \"sh\".\n\
+Input and output redirection with \">\", \"<\", or \">>\" are also \
+allowed.\n\n\
+With no arguments, uses arguments last specified (with \"run\" \
+or \"set args\").\n\
+To cancel previous arguments and run with no arguments,\n\
+use \"set args\" without arguments."));
+  set_cmd_completer (c, filename_completer);
+  add_com_alias ("srun", "serverrun", class_run, 1);
+
+  c = add_com ("gdbserver", class_run, gdbserver_command, _("\
+Run the debugged program until the beginning of the main procedure.\n\
+You may specify arguments to give to your program, just as with the\n\
+\"run\" command."));
+  set_cmd_completer (c, filename_completer);
+
   add_com ("interrupt", class_run, interrupt_command,
 	   _("Interrupt the execution of the debugged program.\n\
 If non-stop mode is enabled, interrupt only the current thread,\n\
