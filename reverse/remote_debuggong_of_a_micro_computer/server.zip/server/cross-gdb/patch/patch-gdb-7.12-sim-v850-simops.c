--- sim/v850/simops.c.orig	2016-08-02 00:50:21.000000000 +0900
+++ sim/v850/simops.c	2017-01-24 22:40:29.930666000 +0900
@@ -1631,6 +1631,7 @@
       switch (FUNC)
 	{
 
+#if 0
 #ifdef HAVE_FORK
 #ifdef TARGET_SYS_fork
 	case TARGET_SYS_fork:
@@ -1639,7 +1640,9 @@
 	  break;
 #endif
 #endif
+#endif
 
+#if 0
 #ifdef HAVE_EXECVE
 #ifdef TARGET_SYS_execv
 	case TARGET_SYS_execve:
@@ -1656,7 +1659,9 @@
 	  }
 #endif
 #endif
+#endif
 
+#if 0
 #if HAVE_EXECV
 #ifdef TARGET_SYS_execv
 	case TARGET_SYS_execv:
@@ -1671,6 +1676,7 @@
 	  }
 #endif
 #endif
+#endif
 
 #if 0
 #ifdef TARGET_SYS_pipe
